<?php
$diccionario=array(
    'titulo_pagina'=>'Ejemplo de MVC',
    'titulo'=>'Articulo 123',
    'contenido'=>'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Incidunt eius aut eaque aspernatur illo modi. Ipsa omnis vero, quo iusto fuga adipisci sapiente cupiditate, sed atque hic distinctio, tempora necessitatibus.',
    'enlace'=>'http://www.google.es',
    'texto_enlace'=>'Google'
);
$diccionario2=array(
    'titulo_pagina'=>'Foto MVC',
    'titulo_foto'=>'foto de MVC en PHP',
    'foto'=>'https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/PHP-logo.svg/1024px-PHP-logo.svg.png',
    'enlace_foto'=>'https://www.php.net/'
);
?>